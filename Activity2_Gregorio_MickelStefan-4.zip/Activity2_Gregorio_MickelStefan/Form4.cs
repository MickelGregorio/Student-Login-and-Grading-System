﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Activity2_Gregorio_MickelStefan
{
    public partial class Form4 : Form
    {
        public Form4()
        {
            InitializeComponent();
        }
        public static string SetValueText16;

        private void button2_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void Form4_Load(object sender, EventArgs e)
        {
            txtFullName.Text = frmMain.SetValueText1 + " " + frmMain.SetValueText2;
            txtCourse.Text = Form2.SetValueText10;
            txtEnglish.Text = Form2.SetValueText11;
            txtMath.Text = Form2.SetValueText12;
            txtScience.Text = Form2.SetValueText13;
            txtFilipino.Text = Form2.SetValueText14;
            txtWRP.Text = Form2.SetValueText15;
            txtGWA.Text = Form4.SetValueText16;

            double sum = (double.Parse(txtEnglish.Text) + double.Parse(txtMath.Text) + double.Parse(txtScience.Text) + double.Parse(txtFilipino.Text) + double.Parse(txtWRP.Text));
            double gwa = sum / 5;

            txtGWA.Text = gwa.ToString();
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Activity2_Gregorio_MickelStefan
{
    public partial class frmMain : Form
    {
        public frmMain()
        {
            InitializeComponent();
        }

        public static string SetValueText1;
        public static string SetValueText2;
        public static string SetValueText3;
        public static string SetValueText4;
        public static string SetValueText5;
        public static string SetValueText6;
        public static string SetValueText7;
        public static string SetValueText8;
        public static string SetValueText9;

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void btnShowResult_Click(object sender, EventArgs e)
        {
            string Gender = String.Empty;
            string Hobbies = String.Empty;
            string City = String.Empty;
            string CivilStatus = String.Empty;

            if (rbnMale.Checked == true)
            {
                Gender = "Male";
            }
            else if (rbnFemale.Checked == true)
            {
                Gender = "Female";
            }

           
            City = cboCity.Text;
            CivilStatus = lstCivilStatus.Text;

            MessageBox.Show("Registration Successful!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);

            SetValueText1 = txtFirstName.Text;
            SetValueText2 = txtLastName.Text;
            SetValueText3 = txtAge.Text;
            SetValueText4 = txtContactNo.Text;
            SetValueText5 = Gender;
            SetValueText6 = City;
            SetValueText7 = CivilStatus;
            SetValueText8 = txtUsername.Text;
            SetValueText9 = txtPassword.Text;
            

            this.Hide();
            Form3 frm3 = new Form3();
            frm3.Show();
        }

        private void frmMain_Load(object sender, EventArgs e)
        {

        }

        private void txtUsername_TextChanged(object sender, EventArgs e)
        {

        }
    }
}

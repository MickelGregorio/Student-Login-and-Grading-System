﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Activity2_Gregorio_MickelStefan
{
    public partial class Form3 : Form
    {
        int attempt = 0;
        public Form3()
        {
            InitializeComponent();
        }

        private void btnSubmit_Click(object sender, EventArgs e)
        {
            string CorrectUserName = frmMain.SetValueText8;
            string Username = txtUsername.Text;
            string CorrectPassword = frmMain.SetValueText9;
            string Password = txtPassword.Text;

            if (Username == CorrectUserName && Password == CorrectPassword)
            {
                MessageBox.Show("Credentials are correct, proceed to login.", "Login Successful", MessageBoxButtons.OK, MessageBoxIcon.Information);
                this.Hide();
                Form2 form2 = new Form2();
                form2.Show();
            }
            else
            {
                attempt++;

                if (attempt >= 3)
                {
                    MessageBox.Show("Too many attempts.", "Login Failed", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    Application.Exit();
                }
                else
                {
                    MessageBox.Show("Incorrect login. Try again."); txtPassword.Clear(); txtPassword.Focus();
                }

            }
        }
    }
}

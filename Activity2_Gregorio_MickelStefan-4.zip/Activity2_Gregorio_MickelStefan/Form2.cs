﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Activity2_Gregorio_MickelStefan
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }
            public static string SetValueText10;
            public static string SetValueText11;
            public static string SetValueText12;
            public static string SetValueText13;
            public static string SetValueText14;
            public static string SetValueText15;
            
            
        private void Form2_Load(object sender, EventArgs e)
        {
            txtFirstName.Text = frmMain.SetValueText1;
            txtLastName.Text = frmMain.SetValueText2;
            txtAge.Text = frmMain.SetValueText3;
            txtContactNo.Text = frmMain.SetValueText4;
            txtGender.Text = frmMain.SetValueText5;
            txtCity.Text = frmMain.SetValueText6;
            txtCivilStatus.Text = frmMain.SetValueText7;
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            
        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void label13_Click(object sender, EventArgs e)
        {

        }

        private void label12_Click(object sender, EventArgs e)
        {

        }

        private void txtCompute_Click(object sender, EventArgs e)
        {
            String Course = String.Empty;
            Course = cbCourse.Text;
            

            SetValueText10 = Course;
            SetValueText11 = txtEnglish.Text;
            SetValueText12 = txtMath.Text;
            SetValueText13 = txtScience.Text;
            SetValueText14 = txtFilipino.Text;
            SetValueText15 = txtWRP.Text;


            this.Hide();
            Form4 frm4 = new Form4();
            frm4.Show();
        }
    }
}
